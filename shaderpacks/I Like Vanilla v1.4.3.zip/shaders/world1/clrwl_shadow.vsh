#version 140

#define SHADER_CLRWL_SHADOW
#define END
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/clrwl_shadow.glsl"
